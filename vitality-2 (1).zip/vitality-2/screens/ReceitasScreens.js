import React, { Component } from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity, FlatList } from "react-native";
import { Avatar, ListItem, Icon } from "react-native-elements";

export default class ReceitasScreens extends Component {
 
    render(){
      return(
        <View>
           <Text>RECEITAS</Text>
        </View>
      )
    }


 }